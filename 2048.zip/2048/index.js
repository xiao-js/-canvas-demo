import Map from './js/map'
import Action from './js/action'
// Map.drawMap()
// Map.drawItem()
document.addEventListener("keydown", e =>{
    console.log(e.which)
    switch(e.which) {
        case 38:
            Action.move("top")
            // Map.drawItem()
            break
        case 39:
            Action.move("right")
            // Map.drawItem()
            break
        case 40:
           Action.move("bottom")
        //    Map.drawItem()
           break
        case 37:
            Action.move("left")
            // Map.drawItem()
            break 
    }
})