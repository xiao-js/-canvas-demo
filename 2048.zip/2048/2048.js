/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _base=__webpack_require__(2);var _base2=_interopRequireDefault(_base);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var
Map=function(_Base){_inherits(Map,_Base);
function Map(){_classCallCheck(this,Map);var _this=_possibleConstructorReturn(this,(Map.__proto__||Object.getPrototypeOf(Map)).call(this));

_this.width=600;
_this.height=600;
_this.radius=400;
_this.begin=(_this.width-_this.radius)/2;
_this.cellWidth=100;
_this.lineWidth=10;return _this;
}_createClass(Map,[{key:'drawItem',value:function drawItem()
{var _this2=this;
this.arrayList.map(function(item,index){
item.map(function(it,ins){
if(it){
_this2.ctx.font='bold 120px consolas';
_this2.ctx.textAlign='center';
_this2.ctx.textBaseline='top';
_this2.ctx.strokeStyle='#DF5326';
_this2.ctx.strokeText(it,150+index*100,100+ins*100);
}else{
_this2.ctx.fillStyle="#fee";
_this2.ctx.fillRect(100+index*100,100+ins*100,100,100);
}
});
});
}},{key:'drawMap',value:function drawMap()
{
this.canvas.width=this.width;
this.canvas.height=this.height;
this.ctx.beginPath();
this.ctx.moveTo(this.begin,this.begin);
this.ctx.lineTo(this.begin+this.radius,this.begin);
this.ctx.lineTo(this.begin+this.radius,this.begin+this.radius);
this.ctx.lineTo(this.begin,this.begin+this.radius);
this.ctx.lineTo(this.begin,this.begin);
this.ctx.lineWidth=10;
this.ctx.strokeStyle="#afe";

this.ctx.moveTo(this.begin+this.cellWidth,this.begin);
this.ctx.lineTo(this.begin+this.cellWidth,this.begin+this.radius);
this.ctx.moveTo(this.begin+this.cellWidth*2,this.begin);
this.ctx.lineTo(this.begin+this.cellWidth*2,this.begin+this.radius);
this.ctx.moveTo(this.begin+this.cellWidth*3,this.begin);
this.ctx.lineTo(this.begin+this.cellWidth*3,this.begin+this.radius);

this.ctx.moveTo(this.begin,this.begin+this.cellWidth);
this.ctx.lineTo(this.begin+this.radius,this.begin+this.cellWidth);
this.ctx.moveTo(this.begin,this.begin+this.cellWidth*2);
this.ctx.lineTo(this.begin+this.radius,this.begin+this.cellWidth*2);
this.ctx.moveTo(this.begin,this.begin+this.cellWidth*3);
this.ctx.lineTo(this.begin+this.radius,this.begin+this.cellWidth*3);
this.ctx.stroke();
}}]);return Map;}(_base2.default);exports.default=

new Map();

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
var _map=__webpack_require__(0);var _map2=_interopRequireDefault(_map);
var _action=__webpack_require__(3);var _action2=_interopRequireDefault(_action);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}


document.addEventListener("keydown",function(e){
console.log(e.which);
switch(e.which){
case 38:
_action2.default.move("top");

break;
case 39:
_action2.default.move("right");

break;
case 40:
_action2.default.move("bottom");

break;
case 37:
_action2.default.move("left");

break;}

});

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}var




Base=function(){
function Base(){_classCallCheck(this,Base);
this.canvas=document.getElementById("canvas");
this.ctx=this.canvas.getContext("2d");
this.url="";
this.arrayList=[
[0,0,0,0],
[0,2,2,2],
[0,0,0,0],
[0,0,4,0]];

console.log(this.arrayList);
}_createClass(Base,[{key:"loadimg",value:function loadimg()
{
this.url=this.canvas.toDataURL();
img=new Image();
img.src=url;
this.ctx.drawImage(img,0,0,this.canvas.width,this.canvas.height);
}},{key:"clear",value:function clear()
{
this.ctx.clearRect(0,0,this.canvas.width,this.canvas.height);
}}]);return Base;}();exports.default=



Base;

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
Object.defineProperty(exports,"__esModule",{value:true});var _createClass=function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if("value"in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};}();var _base=__webpack_require__(2);var _base2=_interopRequireDefault(_base);function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{default:obj};}function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError("Cannot call a class as a function");}}function _possibleConstructorReturn(self,call){if(!self){throw new ReferenceError("this hasn't been initialised - super() hasn't been called");}return call&&(typeof call==="object"||typeof call==="function")?call:self;}function _inherits(subClass,superClass){if(typeof superClass!=="function"&&superClass!==null){throw new TypeError("Super expression must either be null or a function, not "+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}var
Action=function(_Base){_inherits(Action,_Base);
function Action(){_classCallCheck(this,Action);return _possibleConstructorReturn(this,(Action.__proto__||Object.getPrototypeOf(Action)).call(this));


}_createClass(Action,[{key:"aninmation",value:function aninmation()
{

}},{key:"move",value:function move(

direction){var _this2=this;






this.arrayList.map(function(item,index){
item.map(function(it,ins){
if(it&&direction=="right"){
if(item.length-1!==ins){









}
}else if(it&&direction=="bottom"){
if(_this2.arrayList.length-1!==index){
if(_this2.arrayList[index+1][ins]==""){
_this2.arrayList[index+1][ins]=it;
_this2.arrayList[index][ins]=0;
}else if(_this2.arrayList[index+1][ins]==it){
_this2.arrayList[index+1][ins]=it*2;
_this2.arrayList[index][ins]=0;
}
}
}else if(it&&direction=="left"){
if(ins!==0){
if(item[ins-1]==""){
_this2.arrayList[index][ins-1]=it;
_this2.arrayList[index][ins]=0;
}else if(item[ins-1]==it){
_this2.arrayList[index][ins-1]=it*2;
_this2.arrayList[index][ins]=0;
}
}
}else if(it&&direction=="top"){
if(index!==0){
if(_this2.arrayList[index-1][ins]==""){
_this2.arrayList[index-1][ins]=it;
_this2.arrayList[index][ins]=0;
}else if(_this2.arrayList[index-1][ins]==it){
_this2.arrayList[index-1][ins]=it*2;
_this2.arrayList[index][ins]=0;
}
}
}
});
});
console.log(this.arrayList);
}}]);return Action;}(_base2.default);exports.default=

new Action();

/***/ })
/******/ ]);