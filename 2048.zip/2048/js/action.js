import Base from "./base"
class Action extends Base {
    constructor() {
        super()
        
    }
    aninmation() {

    }

    move(direction) {
        // debugger   4000 2200 0004
        //            4200 2220 0024
        //            4400 2222 0044
        //            4000 2020 0004
        //            2400 0240 0024
        //            2400 0024 0024
        this.arrayList.map((item,index)=> {
            item.map((it,ins)=> {
                if(it && direction == "right") {
                    if(item.length-1 !== ins) {
                        // if(item[ins+1] == "") {
                        //     this.arrayList[index][ins+1] = it
                        //     this.arrayList[index][ins] = 0
                        // }else if(item[ins+1] == it) {
                        //     this.arrayList[index][ins+1] = it*2
                        //     this.arrayList[index][ins] = 0
                        // }


                    }
                } else if(it && direction == "bottom") {
                    if(this.arrayList.length-1 !== index) {
                        if(this.arrayList[index+1][ins] == "" ) {
                            this.arrayList[index+1][ins] = it
                            this.arrayList[index][ins] = 0
                        }else if(this.arrayList[index+1][ins] == it) {
                            this.arrayList[index+1][ins] = it*2
                            this.arrayList[index][ins] = 0
                        }
                    }
                } else if(it && direction == "left") {
                    if(ins !== 0) {
                        if(item[ins-1] == "") {
                            this.arrayList[index][ins-1] = it
                            this.arrayList[index][ins] = 0
                        }else if(item[ins-1] == it) {
                            this.arrayList[index][ins-1] = it*2
                            this.arrayList[index][ins] = 0
                        }
                    }
                }else if(it && direction == "top") {
                    if(index !== 0) {
                        if(this.arrayList[index-1][ins] == "" ) {
                            this.arrayList[index-1][ins] = it
                            this.arrayList[index][ins] = 0
                        }else if(this.arrayList[index-1][ins] == it) {
                            this.arrayList[index-1][ins] = it*2
                            this.arrayList[index][ins] = 0
                        }
                    }
                }
            })
        })
        console.log(this.arrayList)
    }
}
export default new Action