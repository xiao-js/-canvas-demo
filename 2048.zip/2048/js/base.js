// function getContext() {
//     let c = document.getElementById("canvas")
//     let ctx=c.getContext("2d")
//     return ctx
// }
class Base {
    constructor() {
        this.canvas = document.getElementById("canvas")
        this.ctx = this.canvas.getContext("2d")
        this.url = ""
        this.arrayList = [
            [0, 0, 0, 0],
            [0, 2, 2, 2],
            [0, 0, 0, 0],
            [0, 0, 4, 0]
        ]
        console.log(this.arrayList)
    }
    loadimg() {
        this.url = this.canvas.toDataURL()
        img = new Image()
        img.src = url
        this.ctx.drawImage(img, 0, 0, this.canvas.width, this.canvas.height)
    }
    clear() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height)
    }
    
}

export default Base;